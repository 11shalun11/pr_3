package Phone;

public class Seller {
    public void change(Phone phone){
        String newModel = phone.getModel();
        newModel = newModel.toLowerCase();
        String newModel2 = newModel.replace('o', 'a');
        String newModel3 = newModel2.replace('O', 'A');
        phone.setModel(newModel3);
    }
}

