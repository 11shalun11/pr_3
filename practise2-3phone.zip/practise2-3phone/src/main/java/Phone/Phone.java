package Phone;

public class Phone {
    public String model;
    private int realease;
    private String capacity;

    public Phone(String model, int realease, String capacity) {
        this.model = model;
        this.realease = realease;
        this.capacity = capacity;
    }

    public Phone() {
    }

    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public int getRealease() {
        return realease;
    }
    public String getCapacity() {
        return capacity;
    }


}
