package Phone;

public class ButtonPhone extends Phone {
    private final String type;
    private final String keyboard;
    public ButtonPhone(String model, int realease, String capacity,String type, String keyboard) {
        super(model, realease, capacity);
        this.type = type;
        this.keyboard = String.valueOf(keyboard);
    }

    public String getType() {
        return type;
    }
    public String getKeyboard() {
        return keyboard;
    }


    @Override
    public String toString() {
        return "Ваше устройство --->" + " Model: " + getModel() + ", Realease: " + getRealease() + ", Capacity: " + getCapacity() + ", Тип корпуса: " + getType() + ", Keyboard: " + getKeyboard() +  " <---";
    }
}