package Phone;
public class Smartphone extends Phone {
    private String touchId;
    private int cameras;
    private int resolution;
    public Smartphone(String model, int realease, String capacity, String touchId, int cameras, String resolution) {
        super(model, realease, capacity);
        this.touchId = touchId;
        this.cameras = cameras;
        this.resolution = Integer.parseInt(resolution);

    }
    public String getTouchId() {
        return touchId;
    }
    public int getCameras() {
        return cameras;
    }
    public int getResolution(){return resolution; }


    @Override
    public String toString() {
        return "Ваше устройство ***" + " Model: " + getModel() + ", Realease: " + getRealease() + ", Capacity: " + getCapacity() + ", Touch: " + getTouchId() + ", Keyboard: " + getCameras() + ", Resolution: " + getResolution() +  "***";
    }
}
